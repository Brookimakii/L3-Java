package rpg.game;

public enum PlayerCast {

    MAGE,
    ELF,
    WARRIOR
}
